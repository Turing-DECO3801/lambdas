var mysql = require('mysql');

const isAlpha = (ch) => {
    return typeof ch === "string" && ch.length === 1 && /[A-Za-z]/.test(ch);
}

exports.handler = async (event, context, callback) => {
    let connection = mysql.createConnection({
        host: "iot-core-database.cyxshb8rdcqi.ap-southeast-2.rds.amazonaws.com",
        user: "admin",
        password: "deco3801",
        port: "3306",
        database: "iotdb"
    });

    let str2 = JSON.stringify(event, null, 2);
    let data = JSON.parse(str2);

    let timestamp = data["timestamp"];
    let payload = data["payload"];

    // let latitude = data["latitude"];
    // let longitutde = data["longitude"];
    // let timestamp = data["time"];
    // let str = 'insert into iot values(';
    // let t = str + latitude;
    // let str1 = ',';
    // let t3 = t + str1 + longitutde;
    // let t5 = t3 + '\,\'' + timestamp;
    // let t2 = '\')';
    // let t4 = t5 + t2;

    for (let i = 0; i < timestamp.length; i++) {
        if (isAlpha(timestamp.charAt(i))) {
            return;
        }
    }

    for (let i = 0; i < payload.length; i++) {
        if (isAlpha(payload.charAt(i))) {
            return;
        }
    }

    let query = `insert into iot values(\'${timestamp}\', \'${payload}\')`;
    
    connection.query(query, function(error, results, fields) {
        if (error) throw error;
        console.log("The solution is: ", results);
    });

    connection.end();
};
